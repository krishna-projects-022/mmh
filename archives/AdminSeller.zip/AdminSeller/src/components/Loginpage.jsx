import React, { useState } from "react";
import image5 from "../assets/image 5.svg";
import { MdOutlineEmail, MdPhone } from "react-icons/md";
import { RiGoogleLine } from "react-icons/ri";
import { FaFacebook } from "react-icons/fa";
import { useNavigate } from "react-router-dom";
import styles from "./Loginpage.module.css"; // ensure this path is correct

const Loginpage = () => {
  const [mode, setMode] = useState("email");
  const [input, setInput] = useState("");
  const navigate = useNavigate();

  const handleInput = (e) => setInput(e.target.value);

  const handleSendOtp = () => {
    if (!input) {
      alert("Please enter your email or phone number");
      return;
    }
    navigate("/signup-step1");
  };

  return (
    <div className={styles.loginContainer}>
      {/* LEFT SIDE */}
      <div
        className={styles.leftBg}
        style={{ backgroundImage: `url(${image5})` }}
      >
        <div className={styles.textOverlay}>
          <h2>Start Selling Today</h2>
          <p>Join thousands of sellers growing their business on our platform</p>
        </div>
      </div>

      {/* RIGHT SIDE */}
      <div className={styles.rightForm}>
        <div className={styles.form}>
          <h2>Create Your Seller Account</h2>
          <p>Start your journey as a seller today</p>

          <div className={styles.toggleTabs}>
            <span
              className={mode === "email" ? styles.active : ""}
              onClick={() => setMode("email")}
            >
              Email
            </span>
            <span
              className={mode === "phone" ? styles.active : ""}
              onClick={() => setMode("phone")}
            >
              Phone
            </span>
          </div>

          <div className={styles.inputArea}>
            {mode === "email" ? (
              <div className={`${styles.inputBox} ${styles.animateSlide}`}>
                <MdOutlineEmail className={styles.icon} />
                <input
                  type="email"
                  placeholder="Enter your email"
                  value={input}
                  onChange={handleInput}
                />
              </div>
            ) : (
              <div className={`${styles.inputBox} ${styles.animateSlide}`}>
                <MdPhone className={styles.icon} />
                <input
                  type="tel"
                  placeholder="Enter your phone number"
                  value={input}
                  onChange={handleInput}
                />
              </div>
            )}
          </div>

          <button className={styles.otpBtn} onClick={handleSendOtp}>
            Send OTP
          </button>

          <div className={styles.divider}>OR</div>

          <button className={styles.googleBtn}>
            <RiGoogleLine /> Continue with Google
          </button>

          <button className={styles.facebookBtn}>
            <FaFacebook /> Continue with Facebook
          </button>

          <p className={styles.loginText}>
            Already have an account? <span className={styles.loginLink}>Log in</span>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Loginpage;
