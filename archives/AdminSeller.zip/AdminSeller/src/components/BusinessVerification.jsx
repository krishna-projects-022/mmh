import React, { useState } from "react";
import { useNavigate } from "react-router-dom"; // ✅ import this
import styles from "./BusinessVerification.module.css";
import { IoCloudUploadOutline } from "react-icons/io5";

const BusinessVerification = () => {
  const navigate = useNavigate(); // ✅ initialize
  const [formData, setFormData] = useState({
    gstNumber: "",
    panNumber: "",
    businessName: "",
    gstFile: null,
    panFile: null,
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleFileChange = (e) => {
    const { name, files } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: files[0],
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    // basic validation
    if (!formData.businessName || !formData.gstNumber || !formData.panNumber) {
      alert("Please fill all fields before continuing!");
      return;
    }

    console.log("Business Verification Data:", formData);

    // ✅ Navigate to next signup step
    navigate("/signup-step2", { state: formData });
  };

  return (
    <div className={styles["bv-wrapper"]}>
      {/* Progress Steps */}
      <div className={styles["bv-steps"]}>
        <div className={`${styles.step} ${styles.active}`}>
          <span>1</span>
          <span>Business Verification</span>
        </div>

        <div className={styles["progress-line"]}>
          <span className={styles.progreeinsid}></span>
        </div>

        <div className={styles.step}>
          <span>2</span>
          <span>Seller Profile</span>
        </div>
      </div>

      {/* Heading */}
      <h1 className={styles["bv-title"]}>Verify Your Business</h1>
      <p className={styles["bv-subtitle"]}>
        Please provide your business details to get started
      </p>

      {/* Form */}
      <form className={styles["bv-form"]} onSubmit={handleSubmit}>
        <label htmlFor="gstNumber">GST Number</label>
        <input
          type="text"
          id="gstNumber"
          name="gstNumber"
          placeholder="22AAAAA0000A1Z5"
          className={styles["bv-input"]}
          value={formData.gstNumber}
          onChange={handleChange}
        />

        <label htmlFor="panNumber">PAN Number</label>
        <input
          type="text"
          id="panNumber"
          name="panNumber"
          placeholder="ABCDE1234F"
          className={styles["bv-input"]}
          value={formData.panNumber}
          onChange={handleChange}
        />

        <label htmlFor="businessName">Business Name</label>
        <input
          type="text"
          id="businessName"
          name="businessName"
          placeholder="Enter your registered business name"
          className={styles["bv-input"]}
          value={formData.businessName}
          onChange={handleChange}
        />

        <label>Upload Documents</label>
        <div className={styles["upload-section"]}>
          <div className={styles["upload-box"]}>
            <IoCloudUploadOutline className={styles["upload-icon"]} />
            <p>GST Certificate</p>
            <span>
              {formData.gstFile
                ? formData.gstFile.name
                : "PDF, JPG, PNG (Max 5MB)"}
            </span>
            <input
              type="file"
              name="gstFile"
              accept=".pdf,.jpg,.png"
              className={styles["file-input"]}
              onChange={handleFileChange}
            />
          </div>

          <div className={styles["upload-box"]}>
            <IoCloudUploadOutline className={styles["upload-icon"]} />
            <p>PAN Card</p>
            <span>
              {formData.panFile
                ? formData.panFile.name
                : "PDF, JPG, PNG (Max 5MB)"}
            </span>
            <input
              type="file"
              name="panFile"
              accept=".pdf,.jpg,.png"
              className={styles["file-input"]}
              onChange={handleFileChange}
            />
          </div>
        </div>

        {/* ✅ Continue navigates to step 2 */}
        <button type="submit" className={styles["continue-btn"]}>
          Continue
        </button>
      </form>
    </div>
  );
};

export default BusinessVerification;
