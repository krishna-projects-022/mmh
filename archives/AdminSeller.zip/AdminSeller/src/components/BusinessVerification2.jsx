import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom'; // ✅ import this
import styles from './BusinessVerification2.module.css';
import { FaCamera } from "react-icons/fa6";

const BusinessVerification2 = () => {
  const navigate = useNavigate(); // ✅ initialize navigation

  const [formData, setFormData] = useState({
    storeName: '',
    businessCategory: '',
    location: '',
    phoneNo: '',
    emailID: '',
    role: null,
  });

  const handleChange = (e) => {
    const { id, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [id]: value,
    }));
  };

  const handleRoleSelect = (selectedRole) => {
    setFormData((prevData) => ({
      ...prevData,
      role: selectedRole,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    // Basic form validation before navigating
    if (
      !formData.storeName ||
      !formData.businessCategory ||
      !formData.location ||
      !formData.phoneNo ||
      !formData.emailID ||
      !formData.role
    ) {
      alert("Please fill all fields before continuing!");
      return;
    }

    console.log('Form Data Submitted:', formData);

    // ✅ Navigate to dashboard after successful submission
    navigate("/dashboard", { state: formData });
  };

  return (
    <div className={styles['bv-wrapper']}>
      {/* Progress Steps */}
      <div className={styles['bv-steps']}>
        <div className={`${styles.step} ${styles.completed}`}>
          <span>1</span>
          <span>Business Verification</span>
        </div>
        <div className={`${styles['progress-line']} ${styles.active}`}>
          <span className={styles.progreeinsid}></span>
        </div>
        <div className={`${styles.step} ${styles.active}`}>
          <span>2</span>
          <span>Seller Profile</span>
        </div>
      </div>

      {/* Heading */}
      <h1 className={styles['bv-title']}>Set Up Your Seller Profile</h1>
      <p className={styles['bv-subtitle']}>
        Tell us about your store to get started selling.
      </p>

      {/* Form */}
      <form className={styles['bv-form']} onSubmit={handleSubmit}>
        <label htmlFor="storeLogo">Store Logo</label>
        <div className={styles['upload-section']}>
          <div className={styles['upload-box']}>
            <span className={styles['upload-icon']}>
              <FaCamera style={{ fontSize: "20px" }} />
            </span>
            <p style={{ color: "grey" }}>Upload</p>

            <input
              type="file"
              id="storeLogo"
              accept=".png,.jpg,.jpeg"
              className={styles['file-input']}
            />
          </div>
        </div>

        <label htmlFor="storeName">Store Name</label>
        <input
          type="text"
          id="storeName"
          placeholder="Enter your store name"
          className={styles['bv-input']}
          value={formData.storeName}
          onChange={handleChange}
        />

        <label htmlFor="businessCategory">Business Category</label>
        <select
          id="businessCategory"
          className={styles['bv-input']}
          value={formData.businessCategory}
          onChange={handleChange}
        >
          <option value="" disabled>
            Select a category
          </option>
          <option value="electronics">Electronics</option>
          <option value="clothing">Clothing</option>
          <option value="homegoods">Home Goods</option>
        </select>

        <label htmlFor="location">Location</label>
        <input
          type="text"
          id="location"
          placeholder="Enter your business location"
          className={styles['bv-input']}
          value={formData.location}
          onChange={handleChange}
        />

        <label htmlFor="phoneNo">Phone Number</label>
        <div className={styles['phone-group']}>
          <select className={styles['country-code']} defaultValue="+91">
            <option value="+1">+1</option>
            <option value="+91">+91</option>
          </select>
          <input
            type="tel"
            id="phoneNo"
            placeholder="Enter phone number"
            className={styles['bv-input']}
            value={formData.phoneNo}
            onChange={handleChange}
          />
        </div>

        <label htmlFor="emailID">Email ID</label>
        <input
          type="email"
          id="emailID"
          placeholder="Enter your email address"
          className={styles['bv-input']}
          value={formData.emailID}
          onChange={handleChange}
        />

        <label>Select Role</label>
        <div className={styles['role-section']}>
          <button
            type="button"
            className={`${styles['role-btn']} ${
              formData.role === 'seller' ? styles.active : ''
            }`}
            onClick={() => handleRoleSelect('seller')}
          >
            I'm Seller
          </button>
          <button
            type="button"
            className={`${styles['role-btn']} ${
              formData.role === 'manufacturer' ? styles.active : ''
            }`}
            onClick={() => handleRoleSelect('manufacturer')}
          >
            I'm Manufacturer
          </button>
        </div>

        {/* ✅ Continue navigates to dashboard */}
        <button type="submit" className={styles['continue-btn']}>
          Continue
        </button>
      </form>
    </div>
  );
};

export default BusinessVerification2;
