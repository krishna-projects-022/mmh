import React from "react";
import { FaSearch } from "react-icons/fa";
import styles from "../pages/ListYourProducts.module.css";

const SearchFilterBar = () => {
  return (
    <div className={styles.searchBar}>
      {/* 🔍 Search input with icon */}
      <div className={styles.searchInputWrapper}>
        <FaSearch className={styles.searchIcon} />
        <input
          type="text"
          placeholder="Search products by name or SKU"
          className={styles.searchInput}
        />
      </div>

      <div style={{ display: "flex", justifyContent: "space-around", width: "400px" }}>
        <select className={styles.select}>
          <option>All Categories</option>
        </select>
        <select className={styles.select}>
          <option>Stock Status</option>
        </select>
        <select className={styles.select}>
          <option>All Status</option>
        </select>
      </div>
    </div>
  );
};

export default SearchFilterBar;
