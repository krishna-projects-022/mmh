import React from "react";
import { BrowserRouter as Router, Routes, Route, useLocation } from "react-router-dom";
import Navbar from "./components/Navbar/Navbar";
import Loginpage from "./components/Loginpage";
import SellerDashboard from "./pages/SellerDashboard";
import ListYourProducts from "./pages/ListYourProduct";
import AddProduct from "./pages/AddProduct";
import Businessverification from "./components/BusinessVerification";
import BusinessVerification2 from "./components/BusinessVerification2";

const AppContent = () => {
  const location = useLocation();

  // Hide navbar on login/signup pages
  const hideNavbarRoutes = ["/", "/signup-step1", "/signup-step2"];
  const shouldShowNavbar = !hideNavbarRoutes.includes(location.pathname);

  return (
    <>
      {shouldShowNavbar && <Navbar />} {/* ✅ Conditional Navbar */}

      <Routes>
        {/* LOGIN / SIGNUP FLOW */}
        <Route path="/" element={<Loginpage />} />
        <Route path="/signup-step1" element={<Businessverification />} />
        <Route path="/signup-step2" element={<BusinessVerification2 />} />

        {/* DASHBOARD FLOW */}
        <Route path="/dashboard" element={<SellerDashboard />} />
        <Route path="/list-products" element={<ListYourProducts />} />
        <Route path="/add-product" element={<AddProduct />} />
      </Routes>
    </>
  );
};

const App = () => (
  <Router>
    <AppContent />
  </Router>
);

export default App;
